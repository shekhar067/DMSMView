declare const styles: {
    storeTasks: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=StoreTasksWebPart.module.scss.d.ts.map
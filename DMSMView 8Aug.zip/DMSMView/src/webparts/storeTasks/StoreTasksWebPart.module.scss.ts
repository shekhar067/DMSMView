/* tslint:disable */
require("./StoreTasksWebPart.module.css");
const styles = {
  storeTasks: 'storeTasks_5c410318',
  teams: 'teams_5c410318',
  welcome: 'welcome_5c410318',
  welcomeImage: 'welcomeImage_5c410318',
  links: 'links_5c410318'
};

export default styles;
/* tslint:enable */
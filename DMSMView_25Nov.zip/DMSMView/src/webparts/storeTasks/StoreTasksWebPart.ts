import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import { escape } from '@microsoft/sp-lodash-subset';
//import './moment-plugin';

require('./moment-plugin');
import styles from './StoreTasksWebPart.module.scss';
import * as strings from 'StoreTasksWebPartStrings';

import 'datatables.net';
import 'moment';


export interface IStoreTasksWebPartProps {
  listName: string;
}
import * as $ from 'jquery';
export default class StoreTasksWebPart extends BaseClientSideWebPart<IStoreTasksWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';
  private userId: number = 0;
  protected onInit(): Promise<void> {
    this._environmentMessage = this._getEnvironmentMessage();
    this.userId = this.context.pageContext.legacyPageContext["userId"];
    return super.onInit();
  }
  public render(): void {
    this.domElement.innerHTML = `
        <table style="color:black !important;">
          <tr>
            <td><label for="start">Start date:</label></td>

            <td>From : <input type="date" id="StartSDate" name="trip-start" placeholder="dd-mm-yyyy" value=""
                min="1997-01-01" max="2030-12-31"></td>

            <td>To : <input type="date" id="StartEDate" name="trip-start" placeholder="dd-mm-yyyy" value=""
                min="1997-01-01" max="2030-12-31"></td>
            <td></td>
          </tr>
          <tr>
            <td><label for="start">Due date:</label></td>

            <td>From : <input type="date" id="DueSDate" name="trip-start" placeholder="dd-mm-yyyy" value=""
                min="1997-01-01" max="2030-12-31"></td>

            <td>To : <input type="date" id="DueEDate" name="trip-start" placeholder="dd-mm-yyyy" value=""
                min="1997-01-01" max="2030-12-31"></td>
            <td>

              <input type="button" value="Apply Date Filter" id="btnDFilter" />
              <input type="button" value="Clear Filter" id="btnClrFilter" /></td>
          </tr>
          <tr><td colspan="3"><button id="btnExport">Export</button></td></tr>
          <table>

          <link rel="stylesheet" type="text/css" href="../SiteAssets/css/dataTables.min.css" />
          <table id="dataTable" class="display ${styles.storeTasks}" cellspacing="0" width="100%">
            <thead>
              <tr>
              <th>Item Link</th>
                <th>ID</th>
                <th>Title</th>
                <th>Start Date</th>
                <th>Due Date</th>
                <th>Task</th>
                <th>Budgeted Hours</th>
              </tr>
            </thead>
          </table>`;
    let listName = this.properties.listName;
    let userId = this.context.pageContext.legacyPageContext["userId"];
    let webUrl=this.context.pageContext.web.absoluteUrl;
    getStoresInfo(webUrl).done(function (officelocation) {
      getDMInfo(webUrl,officelocation, userId).done(function(filterUrl) {
        var finalUrl=webUrl+`/_api/web/lists/getbytitle('` + listName + `')/items?$select=*`+filterUrl;
        console.log('Final Url :'+finalUrl);
        $(document).ready(() => {
          if(finalUrl.indexOf('Title')>-1)
          {
          $('#dataTable', this.domElement).DataTable({
            'ajax': {
              'url': webUrl+`/_api/web/lists/getbytitle('` + listName + `')/items?$select=*` + filterUrl,
              'headers': { 'Accept': 'application/json;odata=nometadata' },
              'dataSrc': function (data) {
                return data.value.map(function (item) {
                  return [
                    '<a target="_blank" href="'+webUrl+'/Lists/Store Locations Tasks/DispForm.aspx?ID='+item.ID+'">View Details</a>',
                    item.ID,
                    item.Title,
                    new Date(item.StartDate), //Start Date
                    new Date(item.DueDate), //Due Date
                    item.Task, //Labour Impact
                    item.Budgeted_x0020_Hours //Task_x0020_Categories
                  ];
                });
              }
            },

            columnDefs: [{
              targets: [3, 4],
              render: ($.fn.dataTable.render as any).moment('MM/DD/YYYY')
              /* render: function (data) {
                 var dt = new Date(data);
                 return (dt.getMonth() + 1) + "/" + dt.getDate() + "/" + dt.getFullYear();
               }*/
            }]
          });
        }
          var table = $('#dataTable').DataTable();
          $(function () {
            $("#btnExport").click(function (e) {
              table.page.len(-1).draw();
              window.open('data:application/vnd.ms-excel,' +
                encodeURIComponent($('#dataTable').parent().html()));
              setTimeout(function () {
                table.page.len(10).draw();
              }, 1000);
            });
          });
          // Event listener to the two range filtering inputs to redraw on input
          $('#StartSDate, #StartEDate,#DueSDate,#DueEDate').keyup(function () {
            table.draw();
          });
          $('#StartSDate, #StartEDate,#DueSDate,#DueEDate').change(function () {
            table.draw();
          });
          $('#btnDFilter,#btnSFilter').click(function () {
            table.draw();
          });
          $('#btnClrFilter').click(function () {
            $('#StartSDate').val('');
            $('#StartEDate').val('');
            $('#DueSDate').val('');
            $('#DueEDate').val('');
            table.draw();
          });
          $.extend($.fn.dataTable.defaults, {
            responsive: true
          });

          $.fn.dataTable.ext.search.push(function (settings, data, dataIndex) {
            var SDate1 = $('#StartSDate').val();
            var SDate2 = $('#StartEDate').val();
            var dDate1 = $('#DueSDate').val();
            var dDate2 = $('#DueEDate').val();
            var sDate = data[3]; // use data for the age column
            var dDate = data[4];

            if (SDate1 != '' && SDate2 != '' && dDate1 != "" && dDate2 != "") {
              if ((new Date(SDate1) <= new Date(sDate) && new Date(sDate) <= new Date(SDate2) && (new Date(dDate1) <= new Date(dDate) && new Date(dDate) <= new Date(dDate2)))) {
                return true;
              }
            }
            else if (SDate1 != '' && SDate2 != '') {
              if ((new Date(SDate1) <= new Date(sDate) && new Date(sDate) <= new Date(SDate2))) {
                return true;
              }
            }
            else if (dDate1 != "" && dDate2 != "") {
              if ((new Date(dDate1) <= new Date(dDate) && new Date(dDate) <= new Date(dDate2))) {
                return true;
              }
            }
            else {
              return true;
            }
            return false;
          });
        });
      });
    });
  }
  private _getEnvironmentMessage(): string {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams
      return this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
    }
    return this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment;
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }
    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;
    this.domElement.style.setProperty('--bodyText', semanticColors.bodyText);
    this.domElement.style.setProperty('--link', semanticColors.link);
    this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered);

  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [{
        header: {
          description: strings.PropertyPaneDescription
        },
        groups: [{
          groupName: strings.BasicGroupName,
          groupFields: [
            PropertyPaneTextField('listName', {
              label: strings.ListNameFieldLabel
            })
          ]
        }]
      }]
    };
  }

  protected get disableReactivePropertyChanges(): boolean {
    return true;
  }
}
function getValueByKey(key: string, data: any) {
  let i, len = data.length;

  for (i = 0; i < len; i++) {
    //console.log(data[i]['Key']);
    if (data[i]['Key'] === key) {
      console.log('Found key .....' + data[i]['Key']);
      return data[i]['Value'];
    }
  }

  return -1;
}
function getStoresInfo(webUrl) {
  var dfd = $.Deferred();

  $.ajax({
    url: `${webUrl}/_api/SP.UserProfiles.PeopleManager/GetMyProperties?$select=*`,
    type: 'GET',
    headers: {
      "accept": "application/json;odata=nometadata",
    },
    success: function (data) {
      var officeLocation = getValueByKey('Office', data.UserProfileProperties);

      console.log('Office Location is: ' + officeLocation);

      if (officeLocation !== undefined) {
        const newArrLoc = officeLocation
          .trim()
          .split(";")
          .filter(v => v.indexOf('Store') > -1)
          .map(v => ({ Title: v.replace('Store#', '') }));

        dfd.resolve(newArrLoc);
      } else {
        dfd.resolve([]);
      }
    },
    error: function (error) {
      alert(JSON.stringify(error));
      dfd.reject(error);
    }
  });

  return dfd.promise();
}
function getDMInfo(webUrl, officeLocation, userId) {
  var dfd = $.Deferred();

  $.ajax({
    url: `${webUrl}/_api/web/lists/getbytitle('Store Locations')/items?&$select=Title&$filter=DMId eq ${userId}`,
    type: 'GET',
    headers: {
      "accept": "application/json;odata=nometadata",
    },
    success: function (data) {
      var storeTitles = officeLocation ? data.value.concat(officeLocation) : data.value;

      var filterUrl = '&$filter=';
      
      storeTitles.forEach(function (v, index) {
        if (v.Title.startsWith('0')) {
          filterUrl += index > 0 ? ` or (Title eq '${v.Title}' or Title eq '${v.Title.substring(1)}')` : `(Title eq '${v.Title}' or Title eq '${v.Title.substring(1)}')`;
        } else {
          filterUrl += index > 0 ? ` or Title eq '${v.Title}'` : `Title eq '${v.Title}'`;
        }
      });

      console.log('FinalUrl: ' + filterUrl);

      dfd.resolve(filterUrl.indexOf('Title') > -1 ? filterUrl : '');
    },
    error: function (error) {
      alert(JSON.stringify(error));
      dfd.reject(error);
    }
  });

  return dfd.promise();
}